import React from 'react';
import Dashboard from './components/Dashboard';

const App = () => (
  <div className="bg-gray-100 font-sans">
    <Dashboard />
  </div>
);

export default App;